export const environment = {
    URL_BACKEND: 'http://127.0.0.1:8000/',
    URL_SERVICIOS: 'http://127.0.0.1:8000/api',
    URL_FROTEND: 'http://localhost:4200',
};
