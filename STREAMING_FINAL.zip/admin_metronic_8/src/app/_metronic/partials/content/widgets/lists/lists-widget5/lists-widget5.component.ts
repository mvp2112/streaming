import { Component } from '@angular/core';

@Component({
  selector: 'app-lists-widget5',
  templateUrl: './lists-widget5.component.html',
})
export class ListsWidget5Component {
  constructor() {}
}
