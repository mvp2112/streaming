import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tables-widget3',
  templateUrl: './tables-widget3.component.html',
})
export class TablesWidget3Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
