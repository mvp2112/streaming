import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-plans',
  templateUrl: './product-plans.component.html',
  styleUrls: ['./product-plans.component.scss']
})
export class ProductPlansComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
